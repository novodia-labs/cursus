* **Novodia Cursus (Bêta 0.1)**
	* [Présentation](/)
	* [Global](/global.md)
	* [Métiers](/metiers.md)
* **Liens**
	* [Définitions](https://www.cidj.com/metiers/)
	* [Docsify](https://docsify.js.org/#/)
	* [Markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)