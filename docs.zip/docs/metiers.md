# Liste des caractéristiques par métier
Certaines caractéristiques sont dépendantes d'un secteur ou d'un métier spécifique.

---

## Mécanicien
Le `mécanicien / la mécanicienne`
 auto devient mécanicien de maintenance. Il effectue des réparations sur les véhicules et réalise l'entretien mécanique, électrique, pneumatique, fluide... Ses compétences se sont élargies avec les équipements électroniques.

### Récurrence
Propriété | Valeur
--- | ---
Liste des véhicules réparés | Lister modèles pris en charge par l'établissement

### Possible

### Référencement

### Imagerie

### Mentions légales

---
