# Liste des caractéristiques globales
Certaines caractéristiques sont récurrentes et indépendantes du métier ou secteur choisi.

---

### Récurrence
Propriété | Valeur
--- | ---
Identité | Nom, prénom, nom société, numéro SIRET/SIREN
Coordonnées | Téléphone, adresse email, adresse postale
Horaires | Jours et heures d'ouverture
Informations légales |  Politique de confidentialité, tarifs, hébergeur
Réseaux sociaux | Facebook, YouTube, Instagram, Twitter

### Intermittence
Propriété | Valeur
--- | ---
Informations légales |  Conditions générales de vente et/ou d'utilisation

### Référencement

### Mentions légales

---